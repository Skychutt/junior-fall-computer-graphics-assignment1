/*
 * ASSIGNMENT 1 STARTER
 *
 * Implement the functions marked TODO.
 * Do not replace them with Babylon.js drawing primitives.
 */

export const WIDTH = 640;
export const HEIGHT = 480;

export function createFramebuffer(width = WIDTH, height = HEIGHT) {
    return {
        width,
        height,
        data: new Uint8ClampedArray(width * height * 4)
    };
}

export function clear(frame, r = 245, g = 245, b = 245, a = 255) {
    for (let i = 0; i < frame.data.length; i += 4) {
        frame.data[i] = r;
        frame.data[i + 1] = g;
        frame.data[i + 2] = b;
        frame.data[i + 3] = a;
    }
}

export function setPixel(frame, x, y, color) {
    x = Math.round(x);
    y = Math.round(y);

    if (x < 0 || x >= frame.width || y < 0 || y >= frame.height) return;

    const i = 4 * (y * frame.width + x);
    frame.data[i] = color.r;
    frame.data[i + 1] = color.g;
    frame.data[i + 2] = color.b;
    frame.data[i + 3] = color.a ?? 255;
}

export function rgb(r, g, b, a = 255) {
    return { r, g, b, a };
}

export function barycentric(P, A, B, C) {
    // TODO Part D:
    // Return { alpha, beta, gamma }.
    // Use the standard 2D barycentric-coordinate formula.
    return { alpha: 0, beta: 0, gamma: 0 };
}

export function drawLineExplicit(frame, x0, y0, x1, y1, color) {
    // TODO Part A:
    // Implement y = mx + b.
    // Remember that x0 === x1 needs separate handling.
}

export function drawLineImplicit(frame, x0, y0, x1, y1, color) {
    // TODO Part B:
    // Use F(x,y) = A*x + B*y + C.
    // Decide which pixels are sufficiently close to F=0.
}

export function edgeFunction(A, B, P) {
    // TODO Part C:
    // Return the signed edge function for directed edge A -> B.
    return 0;
}

export function drawTriangleHalfPlane(frame, A, B, C, color) {
    // TODO Part C:
    // 1. Find triangle bounding box.
    // 2. Test every pixel with the three edge functions.
    // 3. Fill pixels inside the triangle.
}

export function drawTriangleBarycentric(
    frame, A, B, C, colorA, colorB, colorC
) {
    // TODO Part D:
    // 1. Find bounding box.
    // 2. Calculate barycentric coordinates for each pixel.
    // 3. If alpha,beta,gamma are all >= 0, interpolate RGB.
}
