import {
    WIDTH, HEIGHT, createFramebuffer, clear, rgb,
    drawLineExplicit, drawLineImplicit,
    drawTriangleHalfPlane, drawTriangleBarycentric
} from "./rasterization.js";

const canvas = document.getElementById("renderCanvas");
const engine = new BABYLON.Engine(canvas, true);
const scene = new BABYLON.Scene(engine);

const camera = new BABYLON.FreeCamera(
    "camera",
    new BABYLON.Vector3(0, 0, -3),
    scene
);
camera.setTarget(BABYLON.Vector3.Zero());
camera.mode = BABYLON.Camera.ORTHOGRAPHIC_CAMERA;
camera.orthoLeft = -1;
camera.orthoRight = 1;
camera.orthoTop = 1;
camera.orthoBottom = -1;

const plane = BABYLON.MeshBuilder.CreatePlane(
    "framebuffer",
    { width: 2, height: 2 },
    scene
);

const material = new BABYLON.StandardMaterial("framebufferMaterial", scene);
material.backFaceCulling = false;
const texture = new BABYLON.DynamicTexture(
    "softwareFramebuffer",
    { width: WIDTH, height: HEIGHT },
    scene,
    false
);
material.diffuseTexture = texture;
material.emissiveTexture = texture;
plane.material = material;

const frame = createFramebuffer();
let mode = "explicit";

function toScreen(x, y) {
    return { x, y: HEIGHT - 1 - y };
}

function demo() {
    clear(frame);

    // TODO: Complete the demonstrations.
    // The following geometry is intentionally supplied as coordinates,
    // but students must decide how to call their rasterisers.

    const A = toScreen(130, 90);
    const B = toScreen(360, 70);
    const C = toScreen(220, 280);

    if (mode === "explicit") {
        drawLineExplicit(frame, 80, 90, 560, 340, rgb(30, 30, 30));
        drawLineExplicit(frame, 80, 340, 560, 90, rgb(30, 30, 30));
        // Add horizontal, vertical and steep examples.
    }

    if (mode === "implicit") {
        drawLineImplicit(frame, 80, 90, 560, 340, rgb(30, 30, 30));
        drawLineImplicit(frame, 80, 340, 560, 90, rgb(30, 30, 30));
    }

    if (mode === "halfplane") {
        drawTriangleHalfPlane(
            frame, A, B, C, rgb(90, 150, 220)
        );
    }

    if (mode === "barycentric") {
        drawTriangleBarycentric(
            frame, A, B, C,
            rgb(255, 60, 60),
            rgb(60, 220, 80),
            rgb(70, 100, 255)
        );
    }

    if (mode === "house") {
        // TODO: Build the final house entirely using your own
        // line and triangle rasterisers.
    }

    const ctx = texture.getContext();
    const image = ctx.createImageData(WIDTH, HEIGHT);
    image.data.set(frame.data);
    ctx.putImageData(image, 0, 0);
    texture.update();
}

document.querySelectorAll("button[data-mode]").forEach(button => {
    button.addEventListener("click", () => {
        mode = button.dataset.mode;
        document.getElementById("status").textContent =
            "Mode: " + button.textContent;
        demo();
    });
});

engine.runRenderLoop(() => scene.render());

window.addEventListener("resize", () => engine.resize());

demo();
